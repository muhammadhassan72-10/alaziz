(async function(){
  try{
    const res = await fetch('/api/cms/blocks');
    const cms = await res.json();
    document.getElementById('hero-title').innerText = cms.hero.title || 'Welcome';
    document.getElementById('hero-sub').innerText = cms.hero.subtitle || '';
  }catch(e){ console.warn('cms load failed', e); }
})();