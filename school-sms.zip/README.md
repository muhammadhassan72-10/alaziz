# School SMS - Starter Scaffold

This scaffold sets up a minimal Node.js + Express backend with Socket.IO and a simple frontend for the landing page and panels.

Quick start:
1. Copy `.env.example` to `.env` and adjust values.
2. Install dependencies: `npm install`
3. Start MySQL (or use docker-compose)
4. Run `npm run dev`

This is a starter kit. Expand models, controllers, and frontends for each role.