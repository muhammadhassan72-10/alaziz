const { Sequelize, DataTypes } = require('sequelize');
const dotenv = require('dotenv');
dotenv.config();

const sequelize = new Sequelize(process.env.DB_NAME || 'schoolsms', process.env.DB_USER || 'root', process.env.DB_PASS || '', {
  host: process.env.DB_HOST || 'localhost',
  dialect: 'mysql',
  logging: false
});

const db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;

// User model
db.User = sequelize.define('User', {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  name: { type: DataTypes.STRING },
  email: { type: DataTypes.STRING, unique: true },
  password_hash: { type: DataTypes.STRING },
  role: { type: DataTypes.ENUM('admin','principal','teacher','student','parent'), defaultValue: 'student' },
  createdAt: { type: DataTypes.DATE, defaultValue: DataTypes.NOW },
  updatedAt: { type: DataTypes.DATE, defaultValue: DataTypes.NOW }
});

// Student profile
db.Student = sequelize.define('Student', {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  userId: { type: DataTypes.INTEGER },
  admission_no: { type: DataTypes.STRING },
  class: { type: DataTypes.STRING }
});

// Attendance
db.Attendance = sequelize.define('Attendance', {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  studentId: { type: DataTypes.INTEGER },
  className: { type: DataTypes.STRING },
  date: { type: DataTypes.DATEONLY },
  status: { type: DataTypes.ENUM('present','absent','late','excused'), defaultValue: 'absent' },
  recordedBy: { type: DataTypes.INTEGER }
});

module.exports = db;