const express = require('express');
module.exports = function(io){
  const router = express.Router();
  const db = require('../models');

  // mark attendance
  router.post('/mark', async (req, res) => {
    const { studentId, className, date, status, recordedBy } = req.body;
    if(!studentId || !date) return res.status(400).json({ error: 'studentId & date required' });
    const att = await db.Attendance.create({ studentId, className, date, status: status || 'present', recordedBy });
    io.emit('attendance:marked', { studentId, className, date, status: att.status });
    res.json({ ok: true, attendance: att });
  });

  // get attendance for student
  router.get('/student/:id', async (req, res) => {
    const rows = await db.Attendance.findAll({ where: { studentId: req.params.id } });
    res.json(rows);
  });

  return router;
};