const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

const dataPath = path.join(__dirname, '..', 'cms.json');
function readCMS(){ try{ return JSON.parse(fs.readFileSync(dataPath)); }catch(e){ return { hero: { title: 'Your School', subtitle: 'Welcome' } }; } }
function writeCMS(obj){ fs.writeFileSync(dataPath, JSON.stringify(obj, null,2)); }

router.get('/blocks', (req, res) => res.json(readCMS()));
router.put('/blocks', (req, res) => { writeCMS(req.body); res.json({ ok: true }); });

module.exports = router;