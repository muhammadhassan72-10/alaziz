-- minimal seed
CREATE DATABASE IF NOT EXISTS schoolsms;
USE schoolsms;

CREATE TABLE IF NOT EXISTS Users (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(255),
 email VARCHAR(255) UNIQUE,
 password_hash VARCHAR(255),
 role VARCHAR(50),
 createdAt DATETIME,
 updatedAt DATETIME
);

INSERT INTO Users (name,email,password_hash,role,createdAt,updatedAt) VALUES
('Admin','admin@school.com','$2b$10$u1dK...fakehash', 'admin', NOW(), NOW());